import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
       <h1>Welcome to kisal </h1>
       <button className="users-button">Save</button>
      </header>
    </div>
  );
}

export default App;
