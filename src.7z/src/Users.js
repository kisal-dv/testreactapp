import UserForm from "./UserForm";

const Users = () => {
    return (
        <UserForm />
    );
}

export default Users;
